// Vercel (serverless) uchun webhook
const { bot } = require('../bot');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(200).send('Kassa bot ishlayapti');

  const secret = process.env.WEBHOOK_SECRET;
  if (secret && req.headers['x-telegram-bot-api-secret-token'] !== secret) {
    return res.status(401).end();
  }

  try {
    if (!bot.botInfo) bot.botInfo = await bot.telegram.getMe();
    await bot.handleUpdate(req.body);
  } catch (e) {
    console.error('Webhook xato:', e);
  }
  res.status(200).send('OK');
};
